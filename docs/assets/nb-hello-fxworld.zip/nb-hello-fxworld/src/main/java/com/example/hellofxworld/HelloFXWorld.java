package com.example.hellofxworld;

import atlantafx.base.theme.Styles;
import com.dlsc.preferencesfx.PreferencesFx;
import com.dlsc.preferencesfx.model.Category;
import com.dlsc.preferencesfx.model.Group;
import com.dlsc.preferencesfx.model.Setting;
import com.dlsc.preferencesfx.view.PreferencesFxView;
import java.awt.BorderLayout;
import java.util.logging.Logger;
import javafx.scene.Scene;
import org.openide.awt.ActionID;
import org.openide.awt.ActionReference;
import org.openide.windows.TopComponent;
import org.openide.util.Exceptions;
import org.openide.util.NbBundle;
import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.DialogPane;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.StageStyle;
import org.kordamp.ikonli.javafx.FontIcon;
import ste.netbeans.javafx.JFXPanel;


@TopComponent.Description(
        preferredID = HelloFXWorld.PREFERRED_ID,
        persistenceType = TopComponent.PERSISTENCE_ALWAYS,
        iconBase = "com/examples/hellofxworld/logo-16x16.png"
)
@TopComponent.Registration(mode = "output", openAtStartup = true)
@ActionID(category = "Tools", id = HelloFXWorld.PREFERRED_ID)
@ActionReference(path = "Menu/Tools", position = 900)
@TopComponent.OpenActionRegistration(
        displayName = "#CTL_HelloFXWorldAction",
        preferredID = HelloFXWorld.PREFERRED_ID
)
@NbBundle.Messages({
    "CTL_HelloFXWorldAction=Hello FX World",
    "CTL_HelloFXWorldTopComponent=Hello FX World",
    "HINT_HelloFXWorldTopComponent=Hello FX World"
})
public class HelloFXWorld extends TopComponent {
    public static final String PREFERRED_ID = "com-example-HelloFXWorldTopComponent";

    final private Logger LOG = Logger.getLogger(getClass().getName());

    public HelloFXWorld() {
        LOG.info(">>> HelloFXWorldTopComponent");
        setName(Bundle.CTL_HelloFXWorldTopComponent());
        setDisplayName(Bundle.CTL_HelloFXWorldTopComponent());
        setToolTipText(Bundle.HINT_HelloFXWorldTopComponent());
    }

    @Override
    protected void componentOpened() {
        LOG.info(">>> HelloFXWorldTopComponent.componentOpened");
        super.componentOpened();
        if (getComponentCount() == 0) {
            initializeUI();
        }
    }

    private void initializeUI() {
        LOG.info(">>> HelloFXWorldTopComponent.initializeUI");
        setLayout(new BorderLayout());
        try {
            JFXPanel fxPanel = new JFXPanel();
            add(fxPanel, BorderLayout.CENTER);

            Platform.runLater(() -> {
                try {
                    Scene scene = new Scene(root());
                    scene.getStylesheets().add(JFXPanel.CSS);
                    fxPanel.setScene(scene);
                } catch (Exception e) {
                    LOG.severe(String.valueOf(e));
                    Exceptions.printStackTrace(e);
                }
            });
            LOG.info("<<< HelloFXWorldTopComponent.initializeUI");
        } catch (Exception e) {
            LOG.severe(String.valueOf(e));
            Exceptions.printStackTrace(e);
        }
    }

    private HBox root() {
        final StringProperty name = new SimpleStringProperty("FX World");

        Label titleLabel = new Label("Hello FX World");
        titleLabel.setFont(Font.font("System", FontWeight.BOLD, 20));

        Label versionLabel = new Label("Version: 0.0.0");
        Label descriptionLabel = new Label("Demo application for nb-javafx-toolkit");
        Button sayHello = new Button("Say hello", new FontIcon("mdoal-chat_bubble_outline"));
        sayHello.getStyleClass().add(Styles.BUTTON_OUTLINED);
        sayHello.setOnAction((event) -> {
            sayHello(name.get());
        });

        VBox aboutBox = new VBox(10, titleLabel, versionLabel, descriptionLabel, sayHello);
        aboutBox.setMaxWidth(Double.MAX_VALUE);
        aboutBox.setAlignment(Pos.CENTER);

        StackPane about = new StackPane(aboutBox);

        PreferencesFx preferences = PreferencesFx.of(HelloFXWorld.class,
            Category.of(
                "Preferences",
                Group.of("Settings",
                    Setting.of("Your name", name)
                )
            ),
            Category.of(
                "About",
                Group.of(
                    Setting.of(about)
                )
            )
        ).crumbsVisibility(false);

        final HBox container = new HBox();
        HBox.setHgrow(container, Priority.ALWAYS);

        final PreferencesFxView view = preferences.getView();
        view.setPrefWidth(600);
        view.setMinWidth(600);
        view.setMaxWidth(600);

        container.getChildren().add(view);

        return container;
    }

    private void sayHello(final String name) {
        final ButtonType btn = new ButtonType("Close", ButtonBar.ButtonData.APPLY);
        Alert confirm = new Alert(
            Alert.AlertType.CONFIRMATION,
            "Hello %s!".formatted(name),
            btn
        );
        final DialogPane dialog = confirm.getDialogPane();

        dialog.lookupButton(btn).getStyleClass().add(Styles.SMALL);
        ((Label)dialog.lookup(".label.content")).setAlignment(Pos.CENTER_LEFT);

        confirm.setHeaderText(null);
        confirm.initStyle(StageStyle.UNDECORATED);

        confirm.showAndWait();
    }
}
