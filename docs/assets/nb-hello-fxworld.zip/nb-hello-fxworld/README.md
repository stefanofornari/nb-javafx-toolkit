# Hello FX World

A demo application showcasing the integration of JavaFX within NetBeans using the `nb-javafx-toolkit`.

## Requirements

- **Java**: 21+
- **NetBeans JavaFX Toolkit**: the [NetBeans JavaFX Toolkit](https://stefanofornari.github.io/nb-javafx-toolkit/)
- **Build Tool**: Maven (recommended `mvnd`)
- **NetBeans**: RELEASE 280+

## Build and Install

1. Install NetBeans JavaFX Toolkit
2. Build the plug-in
   ```bash
   mvn clean install
   ```
3. Install as a downloaded NetBeans plug-in

## Usage

1. Open NetBeans IDE.
2. The module is registered to open at startup in the `output` window group.
3. Alternatively, navigate to **Tools -> Hello FX World**.

## License

This project is licensed under the Apache License, Version 2.0.
